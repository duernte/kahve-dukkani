1)  PHPmyAdmini açın
2) kahvedukkani adlı bir database oluşturun  db.sql adlı dosyayı buraya içeri aktar
3) kullanıma hazır